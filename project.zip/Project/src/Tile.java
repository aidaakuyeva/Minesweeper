public class Tile {

	private int mine; //1 - has, 0 - does not contain
	private int mineNeighbors; //neighbors with mines
	private boolean covered;
	private boolean flagged;
	private String img;

	//constructor for initial state
	public Tile() {
		this.covered = true;
		this.mine = 0;
		this.mineNeighbors = 0;
		this.flagged = false;	
		img = "files/uncovered.png";
	}
	
	//constructor for other cell
	public Tile(int mineNeighbors, boolean flag, boolean covered, int mine) {
		this.mineNeighbors = mineNeighbors;
		this.flagged = flag;
		this.covered = covered;
		this.mine = mine;
	}
	
	public String getImage() {
		return this.img;
	}
	
	public boolean flagged() {
		return flagged;
	}
	
	public boolean ifOpened() {
		return !covered;
	}
	
	public int getNumNeighbors() {
		return mineNeighbors;
	}
	
	public boolean containsMine( ) {
		return mine == 1;
	}
	
	
	public void setFlag() {
		this.flagged = !this.flagged;
		setImage();
	}
	
	public void uncover() {
		covered = true;
		setImage();
	}
	
	public void setNeighbors(int mineNeighbors) {
		this.mineNeighbors = mineNeighbors;
		setImage();
	}
	
	public void setImage() {
		if (covered) {
			img = "files/uncovered.png";
		} else if (flagged ) {
			img = "files/flagMode.png";
		} else if (mine == 1) {
			img = "files/mine.png";
		} else {
			img = "files/" + mineNeighbors + ".png";
		}
	}
	
}
