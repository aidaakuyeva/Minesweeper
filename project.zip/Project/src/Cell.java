
public class Cell {
	private int mineNeighbors;
	private String imageFile;
	private boolean flag;
	private boolean covered;
	private int mine;
	
	//constructor A for initial state, when each cell is still uncovered
	public Cell() {
		mineNeighbors = 0;
		imageFile = "uncovered.png";
		flag = false;
		covered = true;
		mine = 0;
	}
	
	//constructor B
	public Cell(int mineNeighbors, boolean flag, boolean covered, int mine) {
		this.mineNeighbors = mineNeighbors;
		this.flag = flag;
		this.covered = covered;
		this.mine = mine;
		this.setImage();
	}
	
	/**
	 * Getter function for the image name
	 * @return Image name
	 */
	public String getImg() {
		return imageFile;
	}
	
	/**
	 * Getter function for if the cell is flagged
	 * @return boolean whether the cell was flagged
	 */
	public boolean getIfFlag() {
		return flag;
	}
	
	/**
	 * Getter function for whether the cell was opened or not
	 * @return boolean whether the cell was opened or not
	 */
	public boolean getIfWasNotOpened() {
		return covered;
	}
	
	/**
	 * Getter function for number of mines surrounding that cell
	 * @return number of mines surrounding that cell
	 */
	public int getNumMines() {
		return mineNeighbors;
	}
	
	/**
	 * Getter function if cell contains a mine
	 * @return boolean whether the cell contain a mine
	 */
	public boolean containsMine() {
		return mine == 1;
	}
	
	/**
	 * Setter function to change the mine status of the cell
	 * @param mine 1 if there is a mine, 0 if there is no mine
	 */
	public void setMine(int mine) {
		this.mine = mine;
		this.setImage();
	}
	
	/**
	 * Setter function to change the flag status of the cell
	 * @param flag Flag status
	 */
	public void setFlag(boolean flag) {
		this.flag = flag;
		this.setImage();
	}
	
	/**
	 * Function to uncover the cell
	 */
	public void uncover() {
		covered = false;
		this.setImage();
	}
	
	/**
	 * Function to set the number of surrounding cells with a mine
	 * @param mineNeighbors
	 */
	public void setMineNeighbors(int mineNeighbors) {
		this.mineNeighbors = mineNeighbors;
		this.setImage();
	}
	
	/**
	 * This function sets the image of the cell based on its current condition
	 */
	public void setImage() {
		  if (!flag) {
		   if (covered) {
		    this.imageFile = "uncovered.png";
		   } else if (mine == 1) {
		    this.imageFile = "mine.png";
		   } else {
		    imageFile = mineNeighbors +".png";
		   }
		  } else {
		   this.imageFile = "flagMode.png";
		  } 
		 }

}
