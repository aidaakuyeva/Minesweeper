import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class Game implements Runnable {
	String file = "";
	
	@Override
	public void run() {
		JFrame frame = new JFrame("Minesweeper");
		
		//buttons
		final JButton restart = new JButton("Restart the game");
		frame.add(restart, BorderLayout.WEST);
		
		final JButton flagMode = new JButton("Flag mode");
		frame.add(flagMode, BorderLayout.NORTH);
		
		final JButton instructions = new JButton("Instructions");
		frame.add(instructions, BorderLayout.SOUTH);
		
		final Minesweeper game = new Minesweeper();
	
		frame.add(game, BorderLayout.EAST);
		
		flagMode.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				game.changeFlag();
				if (game.getFlagMode()) {
					flagMode.setText("Unflag Mode");
				} else {
					flagMode.setText("Flag Mode");
				}
			}
		});
		
		restart.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				game.restart();
	
			}
		});
		
		final String rules = "Click on the cell on the field. Then it will show you" +
		"\n the number of mines around it. Your goal is to open as many non-mine" + 
				"\n cells as possible! If you click the mine, you loose. "
				+ "\n If you think you know where the mine is, you can flag it"
				+ "\n by pressing the Flag button and clicking that cell. "
				+ "\n You can restart the game too. Good luck!" ;
		
		instructions.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
                JOptionPane.showMessageDialog(frame, rules, "How to Play", 
                		JOptionPane.PLAIN_MESSAGE);
	
			}
		});
		
		frame.setResizable(true);
		frame.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
		frame.pack();
		frame.setSize(1950, 850);
		frame.setVisible(true);
		
	}
	
    public static void main(String[] args){
        SwingUtilities.invokeLater(new Game());
    }

}
