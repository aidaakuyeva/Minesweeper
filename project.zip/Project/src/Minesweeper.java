import java.io.*;
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

@SuppressWarnings("serial")
public class Minesweeper extends JPanel {
	private int won;
	private final int hStart = 25;
	private final int vStart = 125;
	private final int cellSize = 60;
	private final int boardSize = 750;
	private final int cellWithSpacing = cellSize + 2;
	private Cell[][] field;
	private int openedCells;
	private boolean flagMode;

	public Minesweeper() {
		field = new Cell[9][9];
		flagMode = false;
		openedCells = 0;
		for (int i = 0; i < 9; i++) {
			for (int j = 0; j < 9; j++) {
				field[i][j] = new Cell();
			}
		}
		won = 0;
		listenForClick();

	}

	/**
	 * Getter function to get the current flag mode status
	 * @return flag mode status
	 */
	public boolean getFlagMode() {
		return flagMode;
	}
	
	/**
	 * Getter function to get the current winning status
	 * @return won (1 if won)
	 */
	public int getWon() {
		return won;
	}
	
	/**
	 * Getter function to get the cell with certain row and column
	 * @param row Row of the cell in the field
	 * @param col Column of the cell in the field
	 * @return Cell object at that position
	 */
	public Cell getCell(int row, int col) {
		Cell cell = field[row][col];
		return cell;
	}
	
	/**
	 * Getter function to get the number of opened cells
	 * @return
	 */
	public int getOpenedCells() {
		return openedCells;
	}
	
	
	/**
	 * This function listens for the mouse click and handles the events when the
	 * mouse is clicked for the first time and not
	 */
	public void listenForClick() {
		addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				if (won == 0) {
					int row = (int) (e.getY() - vStart) / cellWithSpacing;
					int col = (int) (e.getX() - hStart) / cellWithSpacing;
					if (col >= 0 && col <= 8 && row >= 0 && row <= 8) {
						// if it is not the first click
						if (!(openedCells == 0)) {
							open(col, row);
						} else {
							openFirst(row, col);
							openedCells++;
						}
						repaint();
					}
				}
			}
		});
		won = 0;
	}

	/**
	 * This function prints whether each cell contains a mine or not
	 */
	public void printMines() {
		for (Cell[] i : field) {
			for (Cell c : i) {
				System.out.print(c.containsMine() + " ");
			}
			System.out.println();
		}
	}
	
	/**
	 * This function gets the field with all the cells
	 * @return cell array as the board
	 */
	public Cell[][] getField() {
		Cell[][] cells = new Cell[9][9];
		for (int row = 0; row < 9; row++) {
			for (int col = 0; col < 9; col++) {
				cells[row][col] = field[row][col];
			}
		}
		return cells;
	}

	/**
	 * This function is called when the user clicks for the first time
	 * 
	 * @param row The row of the clicked cell
	 * @param col The column of the clicked cell
	 */
	public void openFirst(int row, int col) {

		for (int i = 0; i <= 9; i++) {
			int newRow = getRandomPosition();
			int newCol = getRandomPosition();

			Cell cell = field[newRow][newCol];

			while (cell.containsMine() || (newRow == row) && (newCol == col)) {
				newRow = getRandomPosition();
				newCol = getRandomPosition();
				cell = field[newRow][newCol];
			}
			cell.setMine(1);
		}
		updateNeighborMines();
		open(col, row);

	}

	/**
	 * This function outputs the random position between 0 and 8, inclusive
	 * 
	 * @return The random integer
	 */
	private int getRandomPosition() {
		return (int) (Math.random() * 8);
	}

	/**
	 * This function reveals the cell when the user clicks not for the first time If
	 * you are in the flag mode, it changes it to the opposite If you have already
	 * opened it or it is flagged, do not do anything If after opening the cell you
	 * win, loose - save the score to history of scores, otherwise open surrounding
	 * cells if there are no mines
	 * 
	 * @param row Row of the cell
	 * @param col Column of the cell
	 */
	public void open(int row, int col) {
		Cell cell = field[row][col];
		if (openedCells > 0) {
			if (cell.getIfWasNotOpened()) {
				if (flagMode) {
					cell.setFlag(!cell.getIfFlag());
					if (!cell.getIfFlag()) {
						super.repaint();
					}
					return;
				}
			}

			if (cell.getIfFlag() || !cell.getIfWasNotOpened()) {
				return;
			}

		}

		openedCells++;
		cell.uncover();
		// win
		if (openedCells == 71) {
			won = 1;
			write();
			return;
		}

		// loose
		if (cell.containsMine()) {
			System.out.println("You lost!");
			won = -1;
			write();
			return;
		}

		if (cell.getNumMines() == 0) {
			openSurrounding(row, col);
		}
	}

	/**
	 * This function opens the cells recursively while there is no mine around
	 * 
	 * @param row Row of the cell to open
	 * @param col Column of the cell to open
	 */
	public void openRecursively(int row, int col) {
		for (int r = row - 1; r <= row + 1; r++) {
			for (int c = col - 1; c <= col + 1; c++) {
				if (r != -1 || r != 9 || c != -1 || c != 9) {
					Cell cell = field[r][c];
					cell.uncover();
					if (cell.getNumMines() == 0) {
						openRecursively(r, c);
					}

				}
			}
		}
	}

	/**
	 * This function opens the cells surrounding that specific one
	 * 
	 * @param row Row of the initial "center" cell
	 * @param col Column of the initial "center" cell
	 */
	public void openSurrounding(int row, int col) {
		for (int i = row - 1; i <= row + 1; i++) {
			if (i != -1 && i != 9) {
				for (int j = col - 1; j <= col + 1; j++) {
					if (j != -1 && j != 9) {
						if (field[i][j].getIfWasNotOpened()) {
							field[i][j].uncover();
							openedCells++;

							if (field[i][j].getNumMines() == 0) {
								openSurrounding(i, j);
							}
						}
					}
				}
			}
		}
	}

	/**
	 * This function updates the number of neighbor mines for each cell
	 */
	private void updateNeighborMines() {
		for (int row = 0; row <= 8; row++) {
			for (int col = 0; col <= 8; col++) {
				int counter = 0;
				for (int i = row - 1; i <= row + 1; i++) {
					if (i != 9 && i != -1) {
						for (int j = col - 1; j <= col + 1; j++) {
							if (j != -1 && j != 9) {
								if (field[i][j].containsMine()) {
									counter++;
								}
							}
						}
					}
				}
				field[row][col].setMineNeighbors(counter);
			}
		}
	}

	@Override
	public void paintComponent(Graphics g) {
		super.paintComponent(g);
		//background image
		g.drawImage(new ImageIcon("files/background.png").getImage(), 
				0, 40, 600, 650, null);

		//draw each cell
		for (int row = 0; row <= 8; row++) {
			for (int col = 0; col <= 8; col++) {
				try {
					g.drawImage(((new ImageIcon(field[row][col].getImg())).getImage()),
							hStart + (row * cellWithSpacing), vStart + (col * cellWithSpacing), 
							cellSize, cellSize, null);
				} catch (Exception e) {

				}
			}
		}

		if (won == 1) {
			g.drawString("You won the game! Your score has been saved", 150, 30);
		}
		if (won == -1) {
			g.drawString("You lost the game! Your score has been saved", 150, 30);
		}
	}

	@Override
	public Dimension getPreferredSize() {
		return new Dimension(boardSize + 200, boardSize + 100);
	}

	/**
	 * This function changes the flagMode to the opposite
	 * 
	 * @return new flagMode
	 */
	public void changeFlag() {
		flagMode = !flagMode;
	}

	/**
	 * This function restarts the game by generating new empty cells on the field
	 */
	public void restart() {
		for (int row = 0; row < 9; row++) {
			for (int col = 0; col < 9; col++) {
				field[row][col] = new Cell();
			}
		}

		openedCells = 0;
		flagMode = false;
		won = 0;
		repaint();
	}

	/**
	 * This function keeps track of the history of scores and saves them in the file
	 */
	public void write() {
		try {
			File scores = new File("Scores.txt");
			FileReader fr = new FileReader(scores);
			BufferedReader br = new BufferedReader(fr);
			FileWriter fw = new FileWriter(scores, true);
			BufferedWriter out = new BufferedWriter(fw);
			String text = "";
			while (br.readLine() != null) {
				text = br.readLine();

			}
			out.append(openedCells + " ");
			out.newLine();
			out.close();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

}
