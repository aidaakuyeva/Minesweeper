=:=:=:=:=:=:=:=:=:=:=:=:=:=:=:=:=:=:=
CIS 120 Game Project README
PennKey: _______
=:=:=:=:=:=:=:=:=:=:=:=:=:=:=:=:=:=:=

===================
=: Core Concepts :=
===================

- List the four core concepts, the features they implement, and why each feature
  is an appropriate use of the concept. Incorporate the feedback you got after
  submitting your proposal.

  1. 2D array: type Cell[][] that represents the field of the Minesweeper object
  (row and column for each Cell)

  2. Recursion: to open cells that are surrounding the "center" cell if there are no mines
  contained (function openRecursively in Minesweeper)

  3. JUnit testing: GameTest class that tests functions within Minesweeper (like opening the cell
  for the first time, opening the same cell multiple times, changing to flag mode, etc.)

  4. File I/O: keeping track of all the previous scores (history of scores) in the Scores.txt file
  The score in Minesweeper is determined by the number of opened non-mine cells by the time the 
  game ends (so max is 71, since out of 81 cells, 10 are mines)


=========================
=: Your Implementation :=
=========================

- Provide an overview of each of the classes in your code, and what their
  function is in the overall game.
  
  Game class: Java Swing representation (visualization of the game with buttons and a Minesweeper
  object), as well as handling events when this certain button is clicked
  
  Minesweeper class: extends JPanel, since we want it to be drawn in Java Swing
  Includes the game's state, like field with the Cells (2d array), the boolean whether the user
  is still playing or not, number of opened cells, the parameters of the board to draw, a boolean
  whether it is in the FlagMode or not. Includes functions on opening the cell (for the first
  and not first time) when the user clicks the cell, change flagMode, randomize mines after first
  click and so on.
  
  Cell class: a tile representation, includes whether the cell contains a mine, whether is was
  flagged, the String image name, number of surrounding cells with mines, whether is was uncovered
  or not.
  
  GameTest class: test the game's functionality and the edge cases, like opening corner cells,
  cells for the first time, opening the same cell multiple times, changing flag mode, etc.

- Were there any significant stumbling blocks while you were implementing your
  game (related to your design, or otherwise)?
  Visualization(Java Swing)

- Evaluate your design. Is there a good separation of functionality? How well is
  private state encapsulated? What would you refactor, if given the chance?
  I think that the Minesweeper object has a well written private state encapsulation. I don't
  think I would have changed anything in my project except add more features. My functions are 
  separated too because some of them call the other ones. For example, when the mouse is clicked, 
  the logic is the following: if it is for the first time, so number of opened cells is 0, we call 
  openFirst on that cell and randomize mines, otherwise, we open that cell. Within open, we open
  neighbors if there are no mines around or output win/loose and save the scores in the Scores.txt
  file.


========================
=: External Resources :=
========================

- Cite any external resources (libraries, images, tutorials, etc.) that you may
  have used while implementing your game.
  None.
