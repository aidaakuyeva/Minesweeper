import static org.junit.Assert.assertEquals;
import static org.junit.Assert.fail;
import org.junit.Test;

/** 
 *  You can use this file (and others) to test your
 *  implementation.
 */
public class GameTest {

    @Test
    public void testInitialState() {
    	Minesweeper test = new Minesweeper();
    	//expected flag mode
    	assertEquals(false, test.getFlagMode());
    	//expected not win
    	assertEquals(0, test.getWon());
    	//expected number of opened cells
    	assertEquals(0, test.getOpenedCells());
    }
    
    @Test
    public void changeFlagModeOnce() {
    	Minesweeper test = new Minesweeper();
    	test.changeFlag();
    	//expected flag mode
    	assertEquals(true, test.getFlagMode());
    	//expected not win
    	assertEquals(0, test.getWon());
    	//expected number of opened cells
    	assertEquals(0, test.getOpenedCells());
    }
    
    @Test
    public void changeFlagModeMultipleTimes() {
    	Minesweeper test = new Minesweeper();
    	test.changeFlag();
    	//expected flag mode
    	assertEquals(true, test.getFlagMode());
    	//expected not win
    	assertEquals(0, test.getWon());
    	//expected number of opened cells
    	assertEquals(0, test.getOpenedCells());
    	test.changeFlag();
    	//expected flag mode
    	assertEquals(false, test.getFlagMode());
    }
    
    @Test
    public void firstClickMiddle() {
    	Minesweeper test = new Minesweeper();
    	test.openFirst(2, 2);
    	test.changeFlag();
    	//expected flag mode
    	assertEquals(true, test.getFlagMode());
    	
    	if (test.getCell(2, 2).containsMine()) {
    		assertEquals(0, test.getWon());
    	}
    }
    
    @Test
    public void firstClickLeftUpCorner() {
    	Minesweeper test = new Minesweeper();
    	test.openFirst(0, 0);
    	test.changeFlag();
    	//expected flag mode
    	assertEquals(true, test.getFlagMode());
    	if (test.getCell(0, 0).containsMine()) {
    		assertEquals(0, test.getWon());
    	}
    }
    @Test
    public void firstClickRightUpCorner() {
    	Minesweeper test = new Minesweeper();
    	test.openFirst(7, 0);
    	test.changeFlag();
    	//expected flag mode
    	assertEquals(true, test.getFlagMode());
    	if (test.getCell(7, 0).containsMine()) {
    		assertEquals(0, test.getWon());
    	}
    }

    @Test
    public void firstClickLeftDownCorner() {
    	Minesweeper test = new Minesweeper();
    	test.openFirst(0, 7);
    	test.changeFlag();
    	//expected flag mode
    	assertEquals(true, test.getFlagMode());
    	if (test.getCell(0, 7).containsMine()) {
    		assertEquals(0, test.getWon());
    	}
    }
    
    @Test
    public void firstClickRightDownCorner() {
    	Minesweeper test = new Minesweeper();
    	test.openFirst(7, 7);
    	test.changeFlag();
    	//expected flag mode
    	assertEquals(true, test.getFlagMode());
    		assertEquals(0, test.getWon());
    }
    
    @Test
    public void openCellMultipleTimes() {
    	Minesweeper test = new Minesweeper();
    	test.openFirst(3, 4);
    	test.open(3, 4);
    		assertEquals(0, test.getWon());
    }
    
    @Test
    public void openMultipleCells() {
    	Minesweeper test = new Minesweeper();
    	test.openFirst(5, 6);
    	test.open(5, 2);
    	test.open(3, 7);
    	if (test.getCell(5, 2).containsMine() ||
    			test.getCell(3, 7).containsMine()) {
    		assertEquals(-1, test.getWon());
    	}
    }
    
    @Test
    public void openAllCells() {
    	Minesweeper test = new Minesweeper();
    	for (int row = 0; row < 9; row++) {
    		for (int col = 0; col < 9; col++) {
    			test.open(row, col);
    		}
    	}
    	//expected number of opened cells
    	assertEquals(81, test.getOpenedCells());
    }
    
    @Test
    public void flagCells() {
    	Minesweeper test = new Minesweeper();
    	test.changeFlag();
    	for (int row = 0; row < 9; row++) {
    		for (int col = 0; col < 9; col++) {
    			test.open(row, col);
    		}
    	}
    	//expected number of opened cells
    	assertEquals(81, test.getOpenedCells());
    }
    
    @Test
    public void restartGame() {
    	Minesweeper test = new Minesweeper();
    	test.restart();
    	//expected flag mode
    	assertEquals(false, test.getFlagMode());
    	//expected not win
    	assertEquals(0, test.getWon());
    	//expected number of opened cells
    	assertEquals(0, test.getOpenedCells());
    	
    	Cell[][] arr = test.getField();
    	int count = 0;
    	for (int row = 0; row < 9; row++) {
    		for (int col = 0; col < 9; col++) {
    			if (arr[row][col].getImg() == "files/uncovered.png") {
    				count++;
    			}
    		}
    	}
    	assertEquals(81, count);
    }
}
